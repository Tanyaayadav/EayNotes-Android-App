package com.ecohabit.app.ui.habits

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.ecohabit.app.databinding.ActivityAddHabitBinding
import com.ecohabit.app.repository.HabitRepository
import com.ecohabit.app.viewmodel.HabitViewModel
import com.ecohabit.app.viewmodel.ViewModelFactory

class AddHabitActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddHabitBinding
    private lateinit var viewModel: HabitViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddHabitBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = HabitRepository()
        viewModel = ViewModelProvider(this, ViewModelFactory(repository))[HabitViewModel::class.java]

        binding.btnSave.setOnClickListener {
            val name = binding.etHabitName.text.toString()
            val co2 = binding.etCo2Amount.text.toString().toDoubleOrNull() ?: 0.0

            if (name.isNotEmpty()) {
                viewModel.addHabit(name, co2)
                Toast.makeText(this, "Habit Logged!", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Enter habit name", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
