package com.ecohabit.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.ecohabit.app.databinding.ActivityMainBinding
import com.ecohabit.app.repository.HabitRepository
import com.ecohabit.app.ui.habits.AddHabitActivity
import com.ecohabit.app.ui.habits.HabitAdapter
import com.ecohabit.app.viewmodel.HabitViewModel
import com.ecohabit.app.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: HabitViewModel
    private lateinit var adapter: HabitAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val repository = HabitRepository()
        viewModel = ViewModelProvider(this, ViewModelFactory(repository))[HabitViewModel::class.java]

        setupRecyclerView()
        observeData()

        binding.fabAddHabit.setOnClickListener {
            startActivity(Intent(this, AddHabitActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        adapter = HabitAdapter()
        binding.rvHabits.layoutManager = LinearLayoutManager(this)
        binding.rvHabits.adapter = adapter
    }

    private fun observeData() {
        lifecycleScope.launch {
            viewModel.habits.collect { habits ->
                adapter.submitList(habits)
            }
        }
        
        lifecycleScope.launch {
            viewModel.totalCo2.collect { total ->
                binding.tvCo2Savings.text = String.format("%.2f kg CO₂ Saved", total)
                binding.treeView.updateScore(total.toInt())
            }
        }
    }
}
