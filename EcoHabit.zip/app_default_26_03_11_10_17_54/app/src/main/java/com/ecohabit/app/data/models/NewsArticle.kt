package com.ecohabit.app.data.models

import com.squareup.moshi.Json

data class NewsResponse(
    val articles: List<NewsArticle>
)

data class NewsArticle(
    val title: String,
    val description: String?,
    val url: String,
    @Json(name = "urlToImage") val imageUrl: String?,
    val publishedAt: String
)
