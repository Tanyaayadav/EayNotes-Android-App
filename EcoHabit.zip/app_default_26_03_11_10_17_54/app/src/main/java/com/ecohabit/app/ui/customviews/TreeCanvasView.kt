package com.ecohabit.app.ui.customviews

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.ecohabit.app.R
import kotlin.math.cos
import kotlin.math.sin

class TreeCanvasView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val treePaint = Paint().apply {
        color = ContextCompat.getColor(context, R.color.tree_brown)
        strokeWidth = 15f
        isAntiAlias = true
    }

    private val leafPaint = Paint().apply {
        color = ContextCompat.getColor(context, R.color.leaf_green)
        isAntiAlias = true
    }

    private var score: Int = 0

    fun updateScore(newScore: Int) {
        this.score = newScore
        invalidate() // Redraw
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val startX = width / 2f
        val startY = height.toFloat() - 50f
        
        // Base Tree depth based on score (limited to 10 for performance)
        val depth = (score / 10).coerceIn(1, 8)
        drawBranch(canvas, startX, startY, -90.0, depth, 150f)
    }

    private fun drawBranch(canvas: Canvas, x: Float, y: Float, angle: Double, depth: Int, len: Float) {
        if (depth == 0) return

        val x2 = x + (cos(Math.toRadians(angle)) * len).toFloat()
        val y2 = y + (sin(Math.toRadians(angle)) * len).toFloat()

        treePaint.strokeWidth = depth * 2f
        canvas.drawLine(x, y, x2, y2, treePaint)

        if (depth < 3) {
            canvas.drawCircle(x2, y2, 20f, leafPaint)
        }

        drawBranch(canvas, x2, y2, angle - 20, depth - 1, len * 0.75f)
        drawBranch(canvas, x2, y2, angle + 20, depth - 1, len * 0.75f)
    }
}
