package com.ecohabit.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ecohabit.app.data.models.Habit
import com.ecohabit.app.repository.HabitRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HabitViewModel(private val repository: HabitRepository) : ViewModel() {

    private val _habits = MutableStateFlow<List<Habit>>(emptyList())
    val habits: StateFlow<List<Habit>> = _habits

    private val _totalCo2 = MutableStateFlow(0.0)
    val totalCo2: StateFlow<Double> = _totalCo2

    init {
        fetchHabits()
    }

    private fun fetchHabits() {
        viewModelScope.launch {
            repository.getHabits().collect { list ->
                _habits.value = list
                _totalCo2.value = list.sumOf { it.co2Saved }
            }
        }
    }

    fun addHabit(name: String, co2: Double) {
        val habit = Habit(name = name, co2Saved = co2)
        repository.addHabit(habit) { }
    }
}
