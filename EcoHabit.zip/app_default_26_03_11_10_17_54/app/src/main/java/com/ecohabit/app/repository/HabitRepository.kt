package com.ecohabit.app.repository

import com.ecohabit.app.data.models.Habit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class HabitRepository {
    private val database = FirebaseDatabase.getInstance().getReference("habits")
    private val auth = FirebaseAuth.getInstance()

    fun addHabit(habit: Habit, onResult: (Boolean) -> Unit) {
        val userId = auth.currentUser?.uid ?: return
        val habitId = database.push().key ?: return
        val habitWithId = habit.copy(id = habitId, userId = userId)
        
        database.child(userId).child(habitId).setValue(habitWithId)
            .addOnCompleteListener { onResult(it.isSuccessful) }
    }

    fun getHabits(): Flow<List<Habit>> = callbackFlow {
        val userId = auth.currentUser?.uid ?: ""
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val habits = snapshot.children.mapNotNull { it.getValue(Habit::class.java) }
                trySend(habits)
            }
            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }
        database.child(userId).addValueEventListener(listener)
        awaitClose { database.child(userId).removeEventListener(listener) }
    }

    fun deleteHabit(habitId: String) {
        val userId = auth.currentUser?.uid ?: return
        database.child(userId).child(habitId).removeValue()
    }
}
