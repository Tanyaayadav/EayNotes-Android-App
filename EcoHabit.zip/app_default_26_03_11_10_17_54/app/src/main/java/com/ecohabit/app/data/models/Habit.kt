package com.ecohabit.app.data.models

data class Habit(
    val id: String = "",
    val name: String = "",
    val category: String = "General",
    val co2Saved: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false,
    val userId: String = ""
)
