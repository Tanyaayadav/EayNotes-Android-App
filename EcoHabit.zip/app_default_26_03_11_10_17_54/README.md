# EcoHabit - Sustainability Tracking App

EcoHabit is a modern Android application built to help users track their sustainability efforts and visualize their environmental impact.

## Features
- **Firebase Authentication**: Secure user accounts (Email/Password).
- **Habit Tracker**: Log daily sustainability actions with estimated CO₂ savings.
- **Procedural Tree Growth**: A custom Canvas-drawn tree that grows and branches out as user CO₂ savings increase.
- **Real-time Sync**: Habits are stored in Firebase Realtime Database and synced across devices.
- **Climate News**: Fetches the latest climate change news using NewsAPI and Retrofit.

## Prerequisites
- **Android Studio Giraffe** or later.
- **JDK 17**.
- **Firebase Project**: You must create a project at [Firebase Console](https://console.firebase.google.com/).
- **NewsAPI Key**: Get a free key from [NewsAPI.org](https://newsapi.org/).

## Installation & Setup

1.  **Firebase Setup**:
    - Add an Android app to your Firebase project with package name `com.ecohabit.app`.
    - Download `google-services.json` and place it in the `app/` directory of this project.
    - Enable **Authentication** (Email/Password).
    - Enable **Realtime Database** and set rules to:
        